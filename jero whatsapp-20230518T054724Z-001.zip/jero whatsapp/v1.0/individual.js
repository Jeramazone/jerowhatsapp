{
    // the base of operations
    var profile = {
        name: 'jerome',
        contacts: [josh = {
            profile: {},
            messeges: []

        }, cathy = {
            profile: {},
            messeges: []
        }],

    }

    // the loop for showing messeges at the index/chats pages
    function contactList() {
        var cup = document.getElementById('contactList');
        var card = document.createElement('div');
        var file = document.createElement('div');
        var name = document.createElement('div');
        var track = profile.contacts;
        card.classList.add('contactCard');
        file.classList.add('profilPic');
        name.classList.add('profileName');
        card.appendChild(file);
        card.appendChild(name);
        for (var i = 0; i < profile.contacts.length; i++) {
            console.log(card);
            console.log(track[i]);
            

        }
        ;
    }

    contactList();

    // the class adds new contacts to ones profile

    class contact {
        constructor(name) {
            this.name = name;
            this.profile = profile;
            this.messeges = messeges
        }

        receive(msg) {

            var nw = document.createElement('div');
            var bre = document.createElement('br');
            var paren = document.getElementById('parent');
            nw.classList.add('messeges', 'received');
            nw.innerHTML = msg;
            console.log(nw);
            paren.appendChild(nw);
            paren.appendChild(brek);

        }

    }

    // the function adds new received messeges and also appends the ones to be sent
    function append(msg) {
        var msg = document.getElementById('msg').value;
        var nwsg = document.createElement('div');
        var brek = document.createElement('br');
        var parent = document.getElementById('parent');
        nwsg.classList.add('messeges', 'sent');
        nwsg.innerHTML = msg;
        console.log(nwsg);
        parent.appendChild(nwsg);
        parent.appendChild(brek);

        //this is the function for sending messeges

        function receive(msg) {

            var nw = document.createElement('div');
            var bre = document.createElement('br');
            var paren = document.getElementById('parent');
            nw.classList.add('messeges', 'received');
            nw.innerHTML = msg;
            console.log(nw);
            paren.appendChild(nw);
            paren.appendChild(brek);

        }
        receive('who are you');

    }

}
