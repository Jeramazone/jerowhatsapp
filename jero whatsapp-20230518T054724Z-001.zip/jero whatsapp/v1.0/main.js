function append(msg) {
var msg = document.getElementById('msg').value;
    var nwsg = document.createElement('div');
    var brek = document.createElement('br');
    var parent = document.getElementById('parent');
    nwsg.classList.add('messeges','sent');
    nwsg.innerHTML = msg;
        console.log(nwsg);
    parent.appendChild(nwsg);
    parent.appendChild(brek);




    function receive(msg){
    var nwsg = document.createElement('div');
    var brek = document.createElement('br');
    var parent = document.getElementById('parent');
    nwsg.classList.add('messeges','received');
    nwsg.innerHTML = msg;
        console.log(nwsg);
    parent.appendChild(nwsg);
    parent.appendChild(brek);

    
}
 receive('sure');

}







