function go(link) {
    
    
}
    function view() {

        var list = ['tom', 'jack', 'tom', 'jame'];
        var card = document.createElement('div');
        var stack = document.getElementById('list');
        card.classList.add('card', 'contact');
        for (var i = 0; i < list.lenght; i++) {

            console.log(list[i]);

        }

        
    }

view();
