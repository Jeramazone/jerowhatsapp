//underscore wrapper
define(['lib/underscore/underscore-min'], function() {
    return window._;
});
